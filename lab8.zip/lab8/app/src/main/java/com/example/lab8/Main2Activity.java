package com.example.lab8;

public class Main2Activity {
}
