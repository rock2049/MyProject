package pb;
import pc.Car;
public class s5_4 {
	public static void main(String[] args) {
		Car car1 = new Car();
		car1.show();
	}
}
